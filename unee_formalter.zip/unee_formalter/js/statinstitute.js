/* custom code */
jQuery(document).ready(function(){	
	jQuery('#user-register-form').on('change','.field--name-field-state .form-select',function(){		
		var caste_val = jQuery(this).val();
		var ldata = '&parent_target_id_1='+caste_val;
		
		jQuery.ajax({
			/* url: Drupal.url('/rates-api?_format=json'+ldata), */
			url: Drupal.url('/institute-list-service?_format=json'+ldata),
			type:"POST",			
			contentType:"application/json; charset=utf-8",
			dataType:"json",
			success: function(response) {
				/* console.log(response.length); */
				if(response.length=="0"){
					//jQuery(".form-item-field-details-"+strarr[3]+"-field-visit-rates-0-value .form-text").val('');
				}else{
					var option_list='';    
                    //console.log(response);                
                    jQuery.each(response,function(key,value){
                        console.log(value.name);
                        option_list+='<option value="'+value.tid+'">'+value.name+'</option>';
                    });
                    //console.log(option_list);
                    jQuery("#edit-field-institute").children('option:not(:first)').remove();
                    jQuery("#edit-field-institute").append(option_list);
				}				
			}
		});
	});	
	/*Tender edit form change date label.*/	
	jQuery('.node-tender-edit-form .field--name-field-date-range .fieldset-wrapper h4.label:nth-child(1)').text('Published Date');
	jQuery('.node-tender-edit-form .field--name-field-date-range .fieldset-wrapper h4+div+h4.label').text('Last date for Bid Submission');
	/*Tender add form change date label.*/
	jQuery('.node-tender-form .field--name-field-date-range .fieldset-wrapper h4.label:nth-child(1)').text('Published Date');
	jQuery('.node-tender-form .field--name-field-date-range .fieldset-wrapper h4+div+h4.label').text('Last date for Bid Submission');
	
	
});